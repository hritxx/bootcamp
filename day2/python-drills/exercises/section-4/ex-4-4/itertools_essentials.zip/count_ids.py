from itertools import count

id_gen = count()
for _ in range(5):
    print(next(id_gen))
