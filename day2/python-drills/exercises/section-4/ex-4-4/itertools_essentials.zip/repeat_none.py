from itertools import repeat

print(list(repeat(None, 10)))
