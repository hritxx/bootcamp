def make_doubler():
    return lambda x: x * 2
