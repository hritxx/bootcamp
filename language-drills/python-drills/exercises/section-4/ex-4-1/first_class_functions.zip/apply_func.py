def apply(func, value):
    return func(value)
