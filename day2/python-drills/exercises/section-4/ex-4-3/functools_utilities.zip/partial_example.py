from functools import partial
binary = partial(int, base=2)
print(binary("1010"))
