funcs = [abs, str, hex]
results = [f(-42) for f in funcs]
print(results)
