print(list(map(lambda x: x ** 2, [1, 2, 3])))
