from itertools import chain

data = chain([1, 2], [3, 4], [5])
print(list(data))
